// --- CONSTANTES Y ESTADO GLOBAL ---

// 1. Usuarios Autorizados 
const USERS = {
    yoel: '123',
    wilson: 'abcdef',
    cruzc: '7890',
};

// 2. Diccionario de Textos (solo español)
const DICTIONARY = {
    index_title: 'Cruz Roja Boliviana: Ayudar, Servir, Proteger',
    index_subtitle: 'Institución humanitaria y voluntaria al servicio de la comunidad.',
    index_action: 'Iniciar Sesión',
    login_title: 'Inicio de Sesión',
    login_user: 'Usuario',
    login_pass: 'Contraseña',
    login_captcha: 'Verificación Anti-Robot:',
    login_button: 'Entrar',
    home_title: 'Portal de Intranet',
    home_welcome: '¡Bienvenido(a) a la Intranet de la Cruz Roja Boliviana!',
    home_body: 'Nuestra misión es aliviar y prevenir el sufrimiento humano, protegiendo la vida y la salud, y velando por la dignidad de toda persona.',
    home_theme_switch: 'Modo Oscuro',
    nav_logout: 'Cerrar Sesión',
    error_login: 'Usuario, contraseña o Captcha incorrectos. Inténtelo de nuevo.',
};


// --- FUNCIONES DE UTILIDAD (showMessage function se mantiene igual) ---

/**
 * Muestra un mensaje de notificación temporal (Toast) en la esquina.
 */
function showMessage(message, type = 'error') {
    let existingMessage = document.getElementById('app-message');
    if (existingMessage) {
        existingMessage.remove();
    }

    const messageDiv = document.createElement('div');
    messageDiv.id = 'app-message';
    messageDiv.textContent = message;
    messageDiv.className = `fixed top-4 right-4 p-3 rounded-lg shadow-xl text-white z-50 transition-transform transform duration-300 ${
        type === 'error' ? 'bg-red-600' : 'bg-green-600'
    }`;
    
    document.body.appendChild(messageDiv);

    // Ocultar el mensaje después de 4 segundos
    setTimeout(() => {
        messageDiv.classList.add('translate-x-full');
        messageDiv.addEventListener('transitionend', () => messageDiv.remove());
    }, 4000);
}


// =================================================================
//          NUEVA LÓGICA DEL CAPTCHA DE IDENTIFICACIÓN DE PIEZA
// =================================================================

// 1. Array de piezas y sus rutas de imagen
const chessPieces = [
    // Asegúrate de que la ruta '../imagenes/' sea correcta para tu estructura de carpetas
    { name: "caballo", image: "../imagenes/caballo.png" }, 
    { name: "alfil", image: "../imagenes/alfil.png" },
    { name: "torre", image: "../imagenes/torre.png" },
    { name: "reina", image: "../imagenes/reina.png" },

];

/**
 * Genera un nuevo CAPTCHA de identificación de pieza de ajedrez
 * y actualiza el HTML.
 */
function generateCaptcha() {
    const piecesCount = chessPieces.length;
    const randomIndex = Math.floor(Math.random() * piecesCount);
    const selectedPiece = chessPieces[randomIndex];

    // Elementos del DOM (IDs del login.html)
    const captchaImage = document.getElementById('captcha-image');
    const correctValueInput = document.getElementById('correct-captcha-value');
    const captchaQuestion = document.getElementById('captcha-question');
    const answerInput = document.getElementById('captcha-answer');

    if (captchaImage && correctValueInput && captchaQuestion && answerInput) {
        // Muestra la imagen y la pregunta
        captchaImage.src = selectedPiece.image;
        captchaQuestion.textContent = `¿Cómo se llama esta pieza?`;

        // Almacena la respuesta correcta (en minúsculas) en el campo oculto
        correctValueInput.value = selectedPiece.name;
        
        // Limpia la respuesta del usuario
        answerInput.value = ''; 
    }
}

// --- MANEJADOR DE LOGIN ---

function handleLogin(e) {
    e.preventDefault();

    const form = e.target;
    const user = form.elements['username'].value;
    const pass = form.elements['password'].value;
    
    // Captura de valores del NUEVO Captcha de Imagen
    // Se lee del campo de texto visible y del campo oculto (hidden)
    const userInputCaptcha = form.elements['captcha-answer'].value.trim().toLowerCase();
    const correctCaptchaValue = form.elements['correct-captcha-value'].value.trim().toLowerCase();
    
    // 1. Verificar credenciales
    const isUserValid = USERS[user] === pass;
    
    // 2. Verificar Captcha
    // El usuario debe responder exactamente con el nombre de la pieza
    const isCaptchaCorrect = userInputCaptcha === correctCaptchaValue && userInputCaptcha.length > 0;

    if (isUserValid && isCaptchaCorrect) {
        // Lógica de éxito (simulada aquí)
        showMessage("¡Login exitoso! Accediendo al portal.", 'success');
        // Aquí iría el código para redireccionar (ej: window.location.href = 'home.html';)
        setTimeout(() => {
            // Usamos 'index.html' como la página Home que creaste
            window.location.href = 'home.html'; 
        }, 1000); // Redirige después de 1 segundo para que el usuario vea el mensaje de éxito
        
    } else {
        // Fallo: Mostrar error y regenerar Captcha
        showMessage(DICTIONARY.error_login, 'error');
        generateCaptcha(); // Regenera el Captcha para el próximo intento
    }
}

// Inicialización de la página de Login
window.onload = function() {
    // 1. Generar el Captcha al cargar la página de login
    generateCaptcha();
    
    // 2. Adjuntar el manejador de eventos al formulario de login
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.onsubmit = handleLogin;
    }
}