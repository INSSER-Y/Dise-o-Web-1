// --- CONSTANTES Y ESTADO GLOBAL ---

// 1. Usuarios Autorizados (Un usuario por "integrante del grupo")
const USERS = {
    yoel: '123',
    wilson: 'abcdef',
    cruzc: '7890',
};

// 2. Diccionario de Traducciones (para cambio de idioma)
const DICTIONARY = {
    es: {
        index_title: 'Cruz Roja Boliviana: Ayudar, Servir, Proteger',
        index_subtitle: 'Institución humanitaria y voluntaria al servicio de la comunidad.',
        index_action: 'Iniciar Sesión',
        login_title: 'Inicio de Sesión',
        login_user: 'Usuario',
        login_pass: 'Contraseña',
        login_captcha: 'Verificación Anti-Robot (Captcha):',
        login_button: 'Entrar',
        home_title: 'Página Principal',
        home_welcome: '¡Bienvenido(a) a la Intranet de la Cruz Roja Boliviana!',
        home_body: 'Nuestra misión es aliviar y prevenir el sufrimiento humano, protegiendo la vida y la salud, y velando por la dignidad de toda persona, en particular en tiempos de conflicto armado y otras situaciones de emergencia. Contamos con voluntarios comprometidos en todo el territorio nacional, promoviendo la resiliencia comunitaria y la preparación ante desastres.',
        home_lang_switch: 'Cambiar a Inglés',
        home_theme_switch: 'Modo Oscuro',
        nav_logout: 'Cerrar Sesión',
        error_login: 'Usuario, contraseña o Captcha incorrectos. Inténtelo de nuevo.',
    },
    en: {
        index_title: 'Bolivian Red Cross: Help, Serve, Protect',
        index_subtitle: 'Humanitarian and voluntary institution at the service of the community.',
        index_action: 'Login',
        login_title: 'Login',
        login_user: 'Username',
        login_pass: 'Password',
        login_captcha: 'Anti-Robot Verification (Captcha):',
        login_button: 'Enter',
        home_title: 'Home Page',
        home_welcome: 'Welcome to the Bolivian Red Cross Intranet!',
        home_body: 'Our mission is to alleviate and prevent human suffering, protecting life and health, and ensuring the dignity of every person, particularly during armed conflict and other emergency situations. We rely on committed volunteers across the national territory, promoting community resilience and disaster preparedness.',
        home_lang_switch: 'Switch to Spanish',
        home_theme_switch: 'Dark Mode',
        nav_logout: 'Logout',
        error_login: 'Incorrect username, password, or Captcha. Please try again.',
    }
};

// 3. Estado de la Aplicación
let currentState = {
    view: 'index', 
    language: 'es', 
    theme: 'light', 
    captchaValue: 0,
    captchaAnswer: null,
    loggedInUser: null, 
};

// --- FUNCIONES DE UTILIDAD ---

/**
 * Muestra un mensaje de notificación temporal (sustituye a la función alert()).
 */
function showMessage(message, type = 'error') {
    let existingMessage = document.getElementById('app-message');
    if (existingMessage) {
        existingMessage.remove();
    }

    const messageDiv = document.createElement('div');
    messageDiv.id = 'app-message';
    messageDiv.textContent = message;
    messageDiv.className = `fixed top-4 right-4 p-3 rounded-lg shadow-xl text-white z-50 transition-transform transform duration-300 ${
        type === 'error' ? 'bg-red-600' : 'bg-green-600'
    }`;
    
    document.body.appendChild(messageDiv);

    // Ocultar el mensaje después de 4 segundos
    setTimeout(() => {
        messageDiv.classList.add('translate-x-full');
        messageDiv.addEventListener('transitionend', () => messageDiv.remove());
    }, 4000);
}

/**
 * Genera una operación matemática simple para el Captcha.
 */
function generateCaptcha() {
    const num1 = Math.floor(Math.random() * 9) + 1;
    const num2 = Math.floor(Math.random() * 9) + 1;
    currentState.captchaValue = num1 + num2;
    currentState.captchaAnswer = `${num1} + ${num2}`;
}

// --- GESTIÓN DE VISTAS ---

/**
 * Dibuja la vista Index.
 */
function renderIndex() {
    const T = DICTIONARY[currentState.language];
    const html = `
        <div class="text-center">
            <img src="https://placehold.co/100x100/cc0000/ffffff?text=CRB" alt="Logo Cruz Roja Boliviana" class="mx-auto mb-6 rounded-full">
            <h1 class="text-3xl font-bold mb-3 text-primary-red">${T.index_title}</h1>
            <p class="text-gray-600 mb-8">${T.index_subtitle}</p>
            <a href="#" onclick="changeView('login'); return false;" 
               class="inline-block px-8 py-3 bg-primary-red text-white font-semibold rounded-full shadow-lg transition duration-300 btn-hover-effect">
                ${T.index_action}
            </a>
        </div>
    `;
    document.getElementById('view-container').innerHTML = html;
}

/**
 * Dibuja la vista Login (con Captcha).
 */
// --- Fragmento JavaScript para la Lógica de Login y Captcha ---

// --- Fragmento JavaScript para la Lógica de Login y Captcha ---

// Definición de Usuarios de Ejemplo (Adaptar según se necesite)
const USERS = { 
    gerente: 'comcruz123', 
    supervisor: 'pass456', 
    admin: 'admin001' 
};

// Estado para la lógica del Captcha
let captchaState = {
    captchaValue: 0, 
    captchaAnswer: ''
};

// --- FUNCIONES DE UTILIDAD ---

/**
 * Genera una nueva suma simple para el Captcha y actualiza la pantalla.
 */
function generateCaptcha() {
    // Generar dos números aleatorios entre 1 y 9
    const n1 = Math.floor(Math.random() * 9) + 1;
    const n2 = Math.floor(Math.random() * 9) + 1;
    
    captchaState.captchaValue = n1 + n2;
    captchaState.captchaAnswer = `${n1} + ${n2}`;
    
    // Actualiza el span en el HTML
    const displayElement = document.getElementById('captcha-display');
    if (displayElement) {
        displayElement.textContent = captchaState.captchaAnswer;
    }
}

/**
 * Muestra el mensaje de error o éxito usando los estilos definidos en CSS.
 */
function showMessage(message, type = 'error') {
    const errorElement = document.getElementById('error-message');
    if (errorElement) {
        errorElement.textContent = message;
        errorElement.style.display = 'block';
        // Asigna la clase CSS correcta para color/fondo
        errorElement.className = type === 'error' ? 'error-message' : 'success-message';
        
        // Oculta el mensaje después de 5 segundos
        setTimeout(() => {
            errorElement.textContent = '';
            errorElement.style.display = 'none';
        }, 5000);
    }
}


// --- MANEJADOR DE LOGIN ---

function handleLogin(e) {
    e.preventDefault();

    const form = e.target;
    // Obtener valores del formulario
    const user = form.elements['username'].value;
    const pass = form.elements['password'].value;
    // El valor del Captcha debe ser un número
    const captchaInput = parseInt(form.elements['captcha-answer'].value, 10);
    
    // 1. Verificar credenciales
    const isUserValid = USERS[user] === pass;
    
    // 2. Verificar Captcha
    // Verificamos que el CaptchaInput sea un número válido y que coincida con el valor
    const isCaptchaCorrect = !isNaN(captchaInput) && captchaInput === captchaState.captchaValue;

    if (isUserValid && isCaptchaCorrect) {
        // Éxito
        const welcomeMessage = `Acceso exitoso. Bienvenido(a), ${user}. Redirigiendo...`;
        showMessage(welcomeMessage, 'success');
        
        // Opcional: Limpiar los campos después del éxito
        form.reset();
        
        // ** REDIRECCIÓN A PÁGINA DE INTRANET / HOME (Añadido) **
        // En una aplicación real, usaría window.location.href = 'home.html';
        // Aquí simulamos el éxito:
        setTimeout(() => {
            alert(`Simulación: Sesión iniciada para ${user}.`); // Usarías una redirección real aquí.
            generateCaptcha(); // Regenera el captcha por si el usuario regresa.
        }, 2000);
        
    } else {
        // Fallo: Mostrar error y regenerar Captcha
        const errorMessage = 'Error de acceso: Usuario, Contraseña o Verificación incorrectos.';
        showMessage(errorMessage, 'error');
        generateCaptcha(); // Regenera el Captcha para el próximo intento
    }
}

// --- INICIALIZACIÓN ---

window.onload = function() {
    // 1. Generar el Captcha al cargar la página
    generateCaptcha();
    
    // 2. Adjuntar el manejador de eventos al formulario
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.onsubmit = handleLogin;
    }
    
    // 3. Ocultar el mensaje de error al inicio
    const errorElement = document.getElementById('error-message');
    if (errorElement) {
        errorElement.style.display = 'none';
    }
}
/**
 * Dibuja la vista Home (con cambio de idioma y tema).
 */
function renderHome() {
    const T = DICTIONARY[currentState.language];
    // Ajuste de textos para los botones de control
    const themeBtnText = currentState.theme === 'light' ? T.home_theme_switch : T.home_theme_switch.replace('Oscuro', 'Claro').replace('Dark', 'Light');
    const langBtnText = currentState.language === 'es' ? T.home_lang_switch : T.home_lang_switch.replace('Español', 'English').replace('Spanish', 'Inglés');
    
    const html = `
        <!-- Barra de Navegación/Controles (Idioma y Tema) -->
        <div class="flex flex-col sm:flex-row justify-between items-center mb-8 p-3 rounded-lg ${currentState.theme === 'dark' ? 'bg-gray-700' : 'bg-secondary-gray'}">
            <div class="flex space-x-2 mb-4 sm:mb-0">
                <button onclick="toggleTheme()" class="text-sm px-4 py-2 rounded-full font-medium transition duration-300 border border-current ${
                    currentState.theme === 'dark' ? 'text-white bg-gray-600 hover:bg-gray-500' : 'text-gray-700 bg-gray-200 hover:bg-gray-300'
                }">
                    ${themeBtnText}
                </button>
                <button onclick="toggleLanguage()" class="text-sm px-4 py-2 rounded-full font-medium transition duration-300 border border-current ${
                    currentState.theme === 'dark' ? 'text-white bg-gray-600 hover:bg-gray-500' : 'text-gray-700 bg-gray-200 hover:bg-gray-300'
                }">
                    ${langBtnText}
                </button>
            </div>
            
            <button onclick="handleLogout()" class="px-4 py-2 bg-red-500 text-white rounded-full font-medium transition duration-300 hover:bg-red-700 btn-hover-effect">
                ${T.nav_logout} (${currentState.loggedInUser})
            </button>
        </div>

        <!-- Contenido Principal -->
        <h2 class="text-3xl font-extrabold mb-4 text-primary-red">${T.home_title}</h2>
        <div class="p-6 rounded-xl shadow-inner ${currentState.theme === 'dark' ? 'bg-gray-700 text-gray-200' : 'bg-secondary-gray text-gray-800'}">
            <p class="text-xl font-semibold mb-4">${T.home_welcome.replace('Intranet', `<span class="text-primary-red">${currentState.loggedInUser}</span>`)}</p>
            <p class="leading-relaxed text-base">${T.home_body}</p>
        </div>
    `;
    document.getElementById('view-container').innerHTML = html;
}

/**
 * Cambia la vista de la aplicación y redibuja.
 */
function changeView(view) {
    // Redirige a login si intenta ir a home sin estar logeado
    if (view === 'home' && !currentState.loggedInUser) {
        view = 'login';
        showMessage(DICTIONARY[currentState.language].error_login, 'error');
    }
    
    currentState.view = view;
    const container = document.getElementById('view-container');
    
    // Aplicar estilos de tema a la tarjeta principal
    container.className = `w-full max-w-xl shadow-2xl rounded-xl p-8 transition-all duration-300 ${
        currentState.theme === 'dark' ? 'bg-gray-800 text-gray-100' : 'bg-white text-gray-900'
    }`;

    // Renderizar la vista
    switch (view) {
        case 'index':
            renderIndex();
            break;
        case 'login':
            renderLogin();
            break;
        case 'home':
            renderHome();
            break;
        default:
            renderIndex();
    }
}

// --- MANEJADORES DE EVENTOS ---

/**
 * Maneja el envío del formulario de inicio de sesión.
 */
function handleLogin(event) {
    event.preventDefault();

    const form = event.target;
    const username = form.elements['username'].value;
    const password = form.elements['password'].value;
    const captchaInput = parseInt(form.elements['captcha-answer'].value, 10);
    
    const isUserValid = USERS[username] === password;
    const isCaptchaCorrect = captchaInput === currentState.captchaValue;

    if (isUserValid && isCaptchaCorrect) {
        currentState.loggedInUser = username;
        showMessage(`¡Bienvenido, ${username}!`, 'success');
        changeView('home');
    } else {
        showMessage(DICTIONARY[currentState.language].error_login, 'error');
        // Regenerar Captcha en caso de error
        renderLogin(); 
    }
}

/**
 * Cambia entre tema Claro y Oscuro (light/dark).
 */
function toggleTheme() {
    const body = document.body;
    const newTheme = currentState.theme === 'light' ? 'dark' : 'light';
    currentState.theme = newTheme;

    body.classList.remove('theme-light', 'theme-dark');
    body.classList.add(`theme-${newTheme}`);
    
    changeView(currentState.view);
}

/**
 * Cambia entre idioma Español e Inglés (es/en).
 */
function toggleLanguage() {
    const newLang = currentState.language === 'es' ? 'en' : 'es';
    currentState.language = newLang;
    
    changeView(currentState.view);
}

/**
 * Maneja el cierre de sesión y regresa al Index.
 */
function handleLogout() {
    currentState.loggedInUser = null;
    changeView('index');
    showMessage('Sesión cerrada correctamente.', 'success');
}


// --- INICIALIZACIÓN ---

// Se ejecuta al cargar la página
window.onload = function() {
    document.body.classList.add('theme-light'); 
    changeView('index'); 
};