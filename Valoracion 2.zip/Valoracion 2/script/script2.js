// JS BÁSICO: Puedes usarlo para añadir interactividad, como un menú hamburguesa o animaciones.

document.addEventListener('DOMContentLoaded', () => {
    // Ejemplo de un mensaje simple al cargar la página (opcional)
    console.log('El sitio web de Ajedrez Central ha cargado exitosamente.');

    // Aquí iría el código para el carrusel de noticias, o un toggle para menú móvil
    
    /* // Ejemplo de un menú móvil
    const menuButton = document.querySelector('.menu-icon'); // Asumiendo que tienes un icono en HTML
    const navMenu = document.querySelector('nav');

    if (menuButton) {
        menuButton.addEventListener('click', () => {
            navMenu.classList.toggle('active');
        });
    }
    */
 

});
/**
 * Lógica para la gestión del Idioma (Español/Inglés) y el Tema (Día/Noche)
 */

// --- DICCIONARIO DE IDIOMAS ---
const translations = {
    es: {
        // Títulos
        "page-title": "Ajedrez Central | Domina el Tablero",
        // Navegación
        "nav_home": "Inicio",
        "nav_about": "Acerca de Nosotros",
        "nav_programs": "Programas y Clases",
        "nav_tournaments": "Torneos y Eventos",
        "nav_login": "Iniciar Sesión",
        "nav_logo_text": "Ajedrez Central ♟️",
        "nav_theme_day": "Modo Noche",
        "nav_theme_night": "Modo Día",
        // Héroe
        "hero_title": "¡Domina el Tablero!",
        "hero_subtitle": "La Estrategia de los Campeones Comienza Aquí",
        "hero_text": "Somos la principal academia, transformando el pensamiento lógico y las habilidades de competición.",
        "hero_cta": "Ver Nuestros Programas ➡️",
        // Resumen
        "summary_title": "El Ajedrez Es Más Que Un Juego",
        "summary_p1": "Es una herramienta poderosa para desarrollar el pensamiento crítico, la planificación a largo plazo y la concentración. En Ajedrez Central, te equipamos con las tácticas y la mentalidad necesarias para superar cualquier desafío, dentro y fuera del tablero.",
        "summary_p2": "Nuestra metodología combina el estudio de grandes maestros con la práctica activa en torneos, asegurando una curva de aprendizaje rápida y efectiva. ¡Únete a la elite del pensamiento estratégico!",
        "summary_cta": "Conoce a Nuestros Maestros",
    },
    en: {
        // Títulos
        "page-title": "Chess Central | Master the Board",
        // Navegación
        "nav_home": "Home",
        "nav_about": "About Us",
        "nav_programs": "Programs & Classes",
        "nav_tournaments": "Tournaments & Events",
        "nav_login": "Login",
        "nav_logo_text": "Chess Central ♟️",
        "nav_theme_day": "Night Mode",
        "nav_theme_night": "Day Mode",
        // Héroe
        "hero_title": "Master the Board!",
        "hero_subtitle": "The Strategy of Champions Starts Here",
        "hero_text": "We are the leading academy, transforming logical thinking and competitive skills.",
        "hero_cta": "View Our Programs ➡️",
        // Resumen
        "summary_title": "Chess Is More Than A Game",
        "summary_p1": "It's a powerful tool for developing critical thinking, long-term planning, and concentration. At Chess Central, we equip you with the tactics and mindset required to overcome any challenge, on and off the board.",
        "summary_p2": "Our methodology combines the study of grandmasters with active tournament practice, ensuring a fast and effective learning curve. Join the elite of strategic thinking!",
        "summary_cta": "Meet Our Masters",
    }
};

let currentLanguage = 'es';
let currentTheme = 'dia';

// --- GESTIÓN DE IDIOMA ---

/**
 * Aplica las traducciones a todos los elementos con el atributo data-lang-key.
 * @param {string} lang - El código de idioma ('es' o 'en').
 */
function updateLanguage(lang) {
    currentLanguage = lang;
    const dict = translations[lang] || translations['es'];

    // 1. Traducir atributos data-lang-key
    document.querySelectorAll('[data-lang-key]').forEach(element => {
        const key = element.getAttribute('data-lang-key');
        if (dict[key]) {
            element.textContent = dict[key];
        }
    });

    // 2. Traducir títulos específicos (si tienen ID)
    const titleElement = document.getElementById('page-title');
    if (titleElement) {
        titleElement.textContent = dict["page-title"];
    }
    const logoElement = document.getElementById('nav-logo-text');
    if (logoElement) {
        logoElement.textContent = dict["nav_logo_text"];
    }

    // 3. Ajustar el texto del botón de tema después de la traducción
    updateThemeButtonText(currentTheme);
}

// --- GESTIÓN DE TEMA (DÍA/NOCHE) ---

/**
 * Cambia la clase del cuerpo para aplicar el tema.
 * @param {string} theme - 'dia' o 'noche'.
 */
function switchTheme(theme) {
    const body = document.body;
    
    // Quitar clases existentes y añadir la nueva
    body.classList.remove('theme-dia', 'theme-noche');
    body.classList.add(`theme-${theme}`);
    
    // Guardar el estado
    currentTheme = theme;
    localStorage.setItem('theme', theme);

    // Actualizar el texto del botón
    updateThemeButtonText(theme);
}

/**
 * Actualiza el texto del botón de tema según el tema actual y el idioma.
 * @param {string} theme - 'dia' o 'noche'.
 */
function updateThemeButtonText(theme) {
    const themeButton = document.getElementById('theme-switch');
    if (themeButton) {
        const key = theme === 'dia' ? 'nav_theme_day' : 'nav_theme_night';
        // Usa el diccionario del idioma actual para obtener el texto correcto
        const dict = translations[currentLanguage] || translations['es'];
        themeButton.textContent = dict[key];
    }
}

// --- INICIALIZACIÓN ---

document.addEventListener('DOMContentLoaded', () => {
    // 1. Obtener el año actual para el footer
    const yearSpan = document.getElementById('current-year');
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }
    
    // 2. Inicializar Idioma (usar la configuración guardada o el valor por defecto)
    const savedLang = localStorage.getItem('language') || 'es';
    const langSelector = document.getElementById('language-selector');
    if (langSelector) {
        langSelector.value = savedLang;
        updateLanguage(savedLang);

        // Event listener para el selector de idioma
        langSelector.addEventListener('change', (e) => {
            const newLang = e.target.value;
            localStorage.setItem('language', newLang);
            updateLanguage(newLang);
        });
    } else {
        updateLanguage('es'); // Forzar español si no hay selector
    }

    // 3. Inicializar Tema (usar la configuración guardada o el valor por defecto)
    const savedTheme = localStorage.getItem('theme') || 'dia';
    switchTheme(savedTheme);

    // Event listener para el botón de tema
    const themeButton = document.getElementById('theme-switch');
    if (themeButton) {
        themeButton.addEventListener('click', () => {
            const newTheme = currentTheme === 'dia' ? 'noche' : 'dia';
            switchTheme(newTheme);
        });
    }

});