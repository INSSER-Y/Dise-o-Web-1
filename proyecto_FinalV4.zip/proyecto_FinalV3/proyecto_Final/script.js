// Variables y datos de ejemplo
const PRODUCTS = [
  {id:1, name:{es:'Mocacín Clásico', en:'Classic Moccasin'}, price:140, desc:{es:'Cuero genuino, hecho a mano', en:'Genuine leather, handmade'}, img:'img/product-1.jpg'},
  {id:2, name:{es:'Mocacín Urbano', en:'Urban Moccasin'}, price:160, desc:{es:'Cómodo y resistente', en:'Comfortable and durable'}, img:'img/product-2.jpg'},
  {id:3, name:{es:'Mocacín Ejecutivo', en:'Executive Moccasin'}, price:200, desc:{es:'Acabado premium', en:'Premium finish'}, img:'img/product-3.jpg'}
];

// Mostrar año en footer
document.getElementById('year').textContent = new Date().getFullYear();

// --------- LOGIN y CAPTCHA (en login.html) ---------
function generateCaptcha() {
  // Captcha simple: suma de dos números entre 1 y 9
  const a = Math.floor(Math.random()*9)+1;
  const b = Math.floor(Math.random()*9)+1;
  const text = a + ' + ' + b + ' =';
  const result = a + b;
  return {text, result};
}

let currentCaptcha = generateCaptcha();

function refreshCaptchaUI() {
  const el = document.getElementById('captchaText');
  if (el) el.textContent = currentCaptcha.text;
}

document.addEventListener('click', (e)=>{
  if (e.target && e.target.id === 'refreshCaptcha') {
    currentCaptcha = generateCaptcha();
    refreshCaptchaUI();
  }
});

// Manejo del formulario de login
const loginForm = document.getElementById('loginForm');
if (loginForm) {
  refreshCaptchaUI();
  loginForm.addEventListener('submit', (ev)=>{
    ev.preventDefault();
    const user = document.getElementById('username').value.trim();
    const pass = document.getElementById('password').value.trim();
    const cap = document.getElementById('captchaInput').value.trim();
    const error = document.getElementById('error');

    // Usuario demo: alumno1 / abc123
    // También permitimos cualquier usuario "local" para pruebas (no recomendado en producción)
    if (!user || !pass || !cap) {
      if (error) error.textContent = 'Completa todos los campos.';
      return;
    }

    if (String(currentCaptcha.result) !== cap) {
      if (error) error.textContent = 'Captcha incorrecto.';
      currentCaptcha = generateCaptcha();
      refreshCaptchaUI();
      return;
    }

    // Validación sencilla: demo o cualquier usuario con pass 'abc123'
    if ( (user === 'alumno1' && pass === 'abc123') || pass === 'abc123' ) {
      // Guardar sesión simulada en localStorage
      localStorage.setItem('moca_logged','true');
      localStorage.setItem('moca_user', user);
      window.location.href = 'home.html';
    } else {
      if (error) error.textContent = 'Usuario o contraseña incorrectos.';
    }
  });
}

// --------- PROTECCIÓN DE HOME (si deseas proteger) ---------
if (location.pathname.endsWith('home.html')) {
  // Si necesitas acceso sin login, comenta estas líneas
  // Si quieres que cualquiera vea home, no hagas nada
  // Aquí permitimos acceso incluso si no hay login (requisito flexible)
  // if (localStorage.getItem('moca_logged') !== 'true') window.location.href = 'login.html';
}

// --------- LOGOUT (si se implementara botón) ---------
const logoutBtn = document.getElementById('logout');
if (logoutBtn) {
  logoutBtn.addEventListener('click',(e)=>{
    e.preventDefault();
    localStorage.removeItem('moca_logged');
    localStorage.removeItem('moca_user');
    window.location.href = 'index.html';
  });
}

// --------- Mostrar productos en home.html ---------
function renderProducts(lang='es') {
  const container = document.getElementById('productsSection');
  if (!container) return;
  container.innerHTML = '';
  PRODUCTS.forEach(p=>{
    const card = document.createElement('article');
    card.className = 'card';
    card.innerHTML = `
      <img src="${p.img}" alt="${p.name[lang] || p.name.es}">
      <h3>${p.name[lang]}</h3>
      <p class="muted">${p.desc[lang]}</p>
      <div class="price">${p.price} BOB</div>
    `;
    container.appendChild(card);
  });
}

// --------- Cambio de idioma (home.html) ---------
const langSelect = document.getElementById('langSelect');
const storedLang = localStorage.getItem('moca_lang') || 'es';
if (langSelect) {
  langSelect.value = storedLang;
  langSelect.addEventListener('change', (e)=>{
    localStorage.setItem('moca_lang', e.target.value);
    applyLanguage(e.target.value);
    renderProducts(e.target.value);
  });
  applyLanguage(storedLang);
}

// applyLanguage: cambia textos básicos
function applyLanguage(lang='es') 
{

  const loginTitle = document.getElementById('loginTitle');
  const labelUser = document.getElementById('labelUser');
  const labelPass = document.getElementById('labelPass');
  const labelCaptcha = document.getElementById('labelCaptcha');
  const loginBtn = document.getElementById('loginBtn');
  const captchaInput = document.getElementById('captchaInput');
  const userInput = document.getElementById('username');
  const passInput = document.getElementById('password');

  if (loginTitle)
    loginTitle.textContent = lang === 'en' ? 'Login' : 'Iniciar sesión';

  if (labelUser)
    labelUser.textContent = lang === 'en' ? 'Username' : 'Usuario';

  if (labelPass)
    labelPass.textContent = lang === 'en' ? 'Password' : 'Contraseña';

  if (labelCaptcha)
    labelCaptcha.childNodes[0].textContent = lang === 'en'
      ? 'Captcha: '
      : 'Captcha: ';

  if (loginBtn)
    loginBtn.textContent = lang === 'en' ? 'Login' : 'Entrar';

  if (userInput)
    userInput.placeholder = lang === 'en' ? 'username' : 'usuario';

  if (passInput)
    passInput.placeholder = lang === 'en' ? 'password' : 'contraseña';

  if (captchaInput)
    captchaInput.placeholder =
      lang === 'en' ? 'Write the result' : 'Escribe el resultado';

  const title = document.getElementById('siteTitle');
  const tag = document.getElementById('siteTag');
  const welcomeTitle = document.getElementById('welcomeTitle');
  const welcomeText = document.getElementById('welcomeText');
  if (title) title.textContent = (lang==='en' ? 'Moccasins Bolivia' : 'Mocacines Bolivia');
  if (tag) tag.textContent = (lang==='en' ? 'Craftsmanship & quality' : 'Artesanía y calidad');
  if (welcomeTitle) welcomeTitle.textContent = (lang==='en' ? 'Welcome' : 'Bienvenido');
  if (welcomeText) welcomeText.textContent = (lang==='en' ? 'Thanks for visiting our handmade moccasins store.' : 'Gracias por visitar nuestra tienda de mocacines artesanales.');

  const pageTitle = document.getElementById('pageTitle');
  const brandTitle = document.getElementById('brandTitle');
  const brandSubtitle = document.getElementById('brandSubtitle');

  if (pageTitle) pageTitle.textContent =
    (lang === 'en' ? 'Moccasins Bolivia - Home' : 'Mocacines Bolivia - Inicio');

  if (brandTitle) brandTitle.textContent =
    (lang === 'en' ? 'Moccasins Bolivia' : 'Mocacines Bolivia');

  if (brandSubtitle) brandSubtitle.textContent =
    (lang === 'en' ? 'Craftsmanship & quality' : 'Artesanía y calidad');

  const heroTitle = document.getElementById('heroTitle');
  const heroDesc = document.getElementById('heroDesc');
  const heroBtn = document.getElementById('heroBtn');
  const heroImgText = document.getElementById('heroImgText');

  if (heroTitle) heroTitle.textContent =
    (lang==='en' ? 'Welcome to Moccasins Bolivia' : 'Bienvenido a Mocacines Bolivia');
  if (heroDesc) heroDesc.textContent =
    (lang==='en'
      ? 'Handcrafted footwear made in Bolivia. Quality, comfort, and tradition.'
      : 'Calzado artesanal hecho en Bolivia. Calidad, comodidad y tradición.'
    );
  if (heroBtn) heroBtn.textContent =
    (lang==='en' ? 'Go to login' : 'Ir a iniciar sesión');
  if (heroImgText) heroImgText.textContent =
    (lang==='en' ? 'Place your image here' : 'Coloca aquí tu imagen');
}

// --------- Tema claro/oscuro ---------
const themeSelect = document.getElementById('themeSelect');
const storedTheme = localStorage.getItem('moca_theme') || 'light';
if (themeSelect) {
  themeSelect.value = storedTheme;
  themeSelect.addEventListener('change', (e)=>{
    localStorage.setItem('moca_theme', e.target.value);
    applyTheme(e.target.value);
  });
  applyTheme(storedTheme);
}

function applyTheme(t='light') {
  if (t === 'dark') document.documentElement.classList.add('dark');
  else document.documentElement.classList.remove('dark');
}

// Inicializar productos e idioma en carga
document.addEventListener('DOMContentLoaded', ()=>{
  const lang0 = localStorage.getItem('moca_lang') || 'es';
  renderProducts(lang0);
  applyLanguage(lang0);
  applyTheme(localStorage.getItem('moca_theme') || 'light');
});


// Boton de busqueda
document.addEventListener('DOMContentLoaded', function() {
    const selectElement = document.getElementById('search-category');
    const formElement = document.getElementById('searchForm');
    
    // Función para actualizar la acción del formulario cuando cambia la selección
    selectElement.addEventListener('change', function() {
        // Obtenemos el valor (que ahora es el nombre del archivo) de la opción seleccionada
        const selectedPage = selectElement.value;
        
        // Actualizamos el atributo 'action' del formulario
        formElement.action = selectedPage;
        
        // Opcional: Mostrar qué página se cargará
        // console.log("El formulario ahora apunta a: " + formElement.action); 
    });
    
    // Inicializar el formulario con la acción del valor preseleccionado al cargar la página
    formElement.action = selectElement.value;
});


